package org.glassfish.movieplex7.chat;

public class MessageException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public MessageException(Throwable t){
		
		super(t);
		
	}
	

}
